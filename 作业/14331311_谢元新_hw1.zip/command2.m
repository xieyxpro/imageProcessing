A=imread('11.png');

I11=quantize(A,128);
imshow(I11);
saveas(gcf,'level-128','png');

I12=quantize(A,32);
imshow(I12);
saveas(gcf,'level-32','png');

I13=quantize(A,8);
imshow(I13);
saveas(gcf,'level-8','png');

I14=quantize(A,4);
imshow(I14);
saveas(gcf,'level-4','png');

I15=quantize(A,2);
imshow(I15);
saveas(gcf,'level-2','png');