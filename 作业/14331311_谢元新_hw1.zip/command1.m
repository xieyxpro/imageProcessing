A=imread('11.png');%get the photo

I11=scale(A,192,128);
imshow(I11);
saveas(gcf,'192-128','png');

I12=scale(A,96,64);
imshow(I12);
saveas(gcf,'96-64','png');

I12=scale(A,96,64);
imshow(I12);
saveas(gcf,'96-64','png');

I13=scale(A,48,32);
imshow(I13);
saveas(gcf,'48-32','png');

I14=scale(A,24,16);
imshow(I14);
saveas(gcf,'24-16','png');

I15=scale(A,12,8);
imshow(I15);
saveas(gcf,'12-8','png');

I2=scale(A,300,200);
imshow(I2);
saveas(gcf,'300-200','png');

I3=scale(A,450,300);
imshow(I3);
saveas(gcf,'450-300','png');

I4=scale(A,500,200);
imshow(I4);
saveas(gcf,'500-200','png');